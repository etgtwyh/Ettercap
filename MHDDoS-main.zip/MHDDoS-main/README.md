<p align="center"><img src="./screenshot/logo.ico" width="150px" height="150px" alt="aventium softworks"></p>

<h1 align="center">MHDDoS - DDoS Attack Script With 36 Method</h1>

<em><h5 align="center">(Code Lang - Python 3)</h5></em>


<p align="center">Please Don't Hit '.gov'  and '.ir' Websites :)</p>

<p align="center"><img src="https://i.imgur.com/aNrHJcA.png" width="1078" height="433" alt="POWER"></p>
<p align="center"><img src="https://i.imgur.com/ueDhdte.png" width="1078" height="296" alt="SCRIPT"></p>

## Features And Method

 * 💣 Layer7
   * <img src="https://image.flaticon.com/icons/png/128/2431/2431664.png" width="16" height="16" alt="get"> GET | GET Flood
   * <img src="https://cdn0.iconfinder.com/data/icons/database-storage-5/60/server__database__fire__burn__safety-512.png" width="16" height="16" alt="post"> POST | POST Flood
   * <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f9/OVH_Logo.svg/1200px-OVH_Logo.svg.png" width="16" height="16" alt="ovh"> OVH | Bypass OVH
   * <img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/cyber-bullying-2557797-2152371.png" width="16" height="16" alt="stress"> STRESS | Send HTTP Packet With High Byte 
   * <img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/cyber-bullying-2546272-2128939.png" width="16" height="16" alt="ostress"> OSTRESS | STRESS Without Proxy
   * <img src="https://image.flaticon.com/icons/png/512/3132/3132142.png" width="16" height="16" alt="dyn"> DYN | A New Method With Random SubDomain
   * <img src="https://cdn2.iconfinder.com/data/icons/poison-and-venom-fill/160/loris2-512.png" width="16" height="16" alt="slow"> SLOW | Slowloris Old Method of DDoS
   * <img src="https://lyrahosting.com/wp-content/uploads/2020/06/ddos-how-work-icon.png" width="16" height="16" alt="head"> HEAD | https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD
   * <img src="https://cdn.iconscout.com/icon/free/png-512/direct-hit-archery-goal-target-mission-33520.png" width="16" height="16" alt="hit"> HIT | POST Without PROXY
   * <img src="https://img.icons8.com/plasticine/2x/null-symbol.png" width="16" height="16" alt="null"> NULL | Null UserAgent and ...
   * <img src="https://i.pinimg.com/originals/03/2e/7d/032e7d0755cd511c753bcb6035d44f68.png" width="16" height="16" alt="cookie"> COOKIE | Random Cookie PHP 'if (isset($_COOKIE))'
   * <img src="https://image.flaticon.com/icons/png/512/3041/3041248.png" width="16" height="16" alt="brust"> BRUST | A Method with more header
   * <img src="https://image.flaticon.com/icons/png/512/2100/2100795.png" width="16" height="16" alt="pps"> PPS |  Only 'GET / HTTP/1.1\r\n\r\n'
   * <img src="https://cdn3.iconfinder.com/data/icons/internet-security-14/48/DDoS_website_webpage_bomb_virus_protection-512.png" width="16" height="16" alt="even"> EVEN | GET Method with more header
   * <img src="https://masbadar.com/wp-content/uploads/2016/02/Logo-Projects-Shield-2.jpg" width="16" height="16" alt="googleshield"> GSB | Google Project Shield Bypass
   * <img src="https://seeklogo.com/images/D/ddos-guard-logo-CFEFCA409C-seeklogo.com.png" width="16" height="16" alt="DDoSGuard"> DGB | DDoS Guard Bypass
   * <img src="https://i.imgur.com/bGL8qfw.png" width="16" height="16" alt="ArvanCloud"> AVB | Arvan Cloud Bypass
   * <img src="https://techcrunch.com/wp-content/uploads/2019/06/J2LlHqT3qJl0bG9Alpgc-1-730x438.png?w=730" width="16" height="16" alt="CloudFlare"> CFB | CloudFlare Bypass
   * <img src="http://iclouddnsbypass.com/wp-content/uploads/2015/02/iCloudDNSBypassServer.ico" width="16" height="16" alt="bypass"> BYPASS |  Bypass Normal AntiDDoS


* 🧨 Layer4: 
  * <img src="https://raw.githubusercontent.com/kgretzky/pwndrop/master/media/pwndrop-logo-512.png" width="16" height="16" alt="tcp"> TCP | TCP Flood Bypass
  * <img src="https://styles.redditmedia.com/t5_2rxmiq/styles/profileIcon_snoob94cdb09-c26c-4c24-bd0c-66238623cc22-headshot.png" width="16" height="16" alt="udp"> UDP | UDP Flood Bypass
  * <img src="https://belgium.devoteam.com/wp-content/uploads/sites/23/2020/06/Icon-accelarate-hyper-automation-with-RPA-300x301.png" width="16" height="16" alt="syn"> SYN | SYN Flood
  * <img src="https://cdn.iconscout.com/icon/free/png-256/virus-2165355-1821015.png" width="16" height="16" alt="vse"> VSE | VSE Flood Only Connection
  * <img src="https://cdn.iconscout.com/icon/free/png-512/redis-4-1175103.png" width="16" height="16" alt="mem"> MEM | Memcached Flood
  * <img src="https://lyrahosting.com/wp-content/uploads/2020/06/ddos-attack-icon.png" width="16" height="16" alt="ntp"> NTP | NTP Flood OLD Method Of Layer4

* 🏹 Layer3
  * <img src="https://image.flaticon.com/icons/png/512/388/388466.png" width="16" height="16" alt="icmp"> ICMP | Flood ICMP Request
  * ⚔️ POD | Ping Of Death OLD Method Of DDoS

* ⚙️ Tools - Run With 'python3 start.py tools'
  * 🌟 CFIP | Find Real IP address of Website Powered by Cloudflare
  * 🔪 DNS | Show Site DNS Records
  * ⚠️ PING | PING server
  * 📌 CHECK | Check Website Die or no
  * 😎 DSTAT | a Method show Receive And Send Bytes Size

* 🎩 Other
  * ❌ STOP | STOP All Attacks
  * 🌠 TOOLS | Tools Console
  * 👑 HELP | Show Usge Script

* Layer4 DDoS Script
#### Issues ? 
 * Telegram : https://t.me/DD0SChat
 * Discord : MH_ProDev#2681
 * [GitHub][github]
#### Like the project? Leave a ⭐ star on the repository!

## Downloads

You can download from [GitHub Releases](https://github.com/MHProDev/MHDDoS/releases)

### Getting Started

**Requirements**

* [Python3][python3]
* requests
* PySocks
* cfscrape
* icmplib
* scapy
---

**Video's**

* Aparat: https://www.aparat.com/v/bHcP9
* YouTube : Coming soon..

**toturial**

* Aprat : https://aparat.com/v/XPn5Z
* YouTube : https://youtu.be/mZilAOkLKK8
---

**Clone and Install Script**

```console
git clone https://github.com/MHProDev/MHDDoS.git
cd MHDDoS
pip3 install -r requirements.txt
```

---

**Launch Script**

```console
python3 start.py
python3 start.py bypass https://example.com 5 1000 socks5.txt 100 100
```

[python3]: https://python.org 'Python3'
[github]: https://github.com/MHProDev/MHDDoS/issues 'GitHub'

**💰 Donate:**
* https://idpay.ir/mh-prodev
* bitcoincash:qrwytj0aghszlqmfnku2h5ms4fad567ueg5g9dn2nu

